import { createClient } from "@/lib/supabase/server";

export async function getCurrentProfile() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null;
  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single();
  return profile;
}

export async function getMyTeams() {
  const supabase = await createClient();
  const { data } = await supabase
    .from("team_members")
    .select("role, teams(id, name, owner_id, created_at)")
    .order("joined_at", { ascending: true });
  return (data ?? []).map((row: any) => ({ ...row.teams, role: row.role }));
}

export async function getTeam(teamId: string) {
  const supabase = await createClient();
  const { data } = await supabase.from("teams").select("*").eq("id", teamId).single();
  return data;
}

export async function getTeamMembers(teamId: string) {
  const supabase = await createClient();
  const { data } = await supabase
    .from("team_members")
    .select("id, role, joined_at, profiles(id, name, email)")
    .eq("team_id", teamId)
    .order("joined_at", { ascending: true });
  return data ?? [];
}

export async function getUpcomingMeetings(limit = 6) {
  const supabase = await createClient();
  const { data } = await supabase
    .from("meetings")
    .select("*, teams(name)")
    .in("status", ["scheduled", "live"])
    .order("start_time", { ascending: true })
    .limit(limit);
  return data ?? [];
}

export async function getAllMeetings() {
  const supabase = await createClient();
  const { data } = await supabase
    .from("meetings")
    .select("*, teams(name)")
    .order("start_time", { ascending: false });
  return data ?? [];
}

export async function getTeamMeetings(teamId: string) {
  const supabase = await createClient();
  const { data } = await supabase
    .from("meetings")
    .select("*")
    .eq("team_id", teamId)
    .order("start_time", { ascending: false });
  return data ?? [];
}

export async function getMeeting(id: string) {
  const supabase = await createClient();
  const { data } = await supabase
    .from("meetings")
    .select("*, teams(id, name)")
    .eq("id", id)
    .single();
  return data;
}

export async function getMeetingParticipants(meetingId: string) {
  const supabase = await createClient();
  const { data } = await supabase
    .from("meeting_participants")
    .select("id, joined_at, left_at, profiles(id, name, email)")
    .eq("meeting_id", meetingId);
  return data ?? [];
}
