export default function AuthCard({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen items-center justify-center bg-[#0B0B0D] px-4">
      <div className="w-full max-w-sm space-y-8">
        <div className="flex items-center gap-2">
          <span className="live-dot h-2.5 w-2.5 rounded-full bg-[#FF3B30]" />
          <span className="font-[family-name:var(--font-display)] text-lg font-semibold">Nexus Studio</span>
        </div>
        {children}
      </div>
    </div>
  );
}
