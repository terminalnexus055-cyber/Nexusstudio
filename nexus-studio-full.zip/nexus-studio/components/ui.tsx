import type { ReactNode } from "react";

export function Button({
  variant = "primary",
  className = "",
  children,
  ...props
}: { variant?: "primary" | "secondary" | "ghost" | "danger" } & React.ButtonHTMLAttributes<HTMLButtonElement>) {
  const base =
    "inline-flex items-center justify-center gap-2 rounded-md px-4 py-2 text-sm font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed";
  const variants: Record<string, string> = {
    primary: "bg-[#FF3B30] text-white hover:bg-[#E8362C]",
    secondary: "bg-[#1C1C24] text-[#F2F0EB] border border-[#26262E] hover:bg-[#22222B]",
    ghost: "text-[#8C8B93] hover:text-[#F2F0EB]",
    danger: "border border-[#FF3B30] text-[#FF3B30] hover:bg-[rgba(255,59,48,0.1)]",
  };
  return (
    <button className={`${base} ${variants[variant]} ${className}`} {...props}>
      {children}
    </button>
  );
}

export function Card({ className = "", children }: { className?: string; children: ReactNode }) {
  return <div className={`rounded-xl border border-[#26262E] bg-[#15151B] p-5 ${className}`}>{children}</div>;
}

const STATUS_STYLES: Record<string, string> = {
  scheduled: "bg-[rgba(245,200,76,0.12)] text-[#F5C84C]",
  live: "bg-[rgba(255,59,48,0.12)] text-[#FF3B30]",
  completed: "bg-[rgba(52,199,89,0.12)] text-[#34C759]",
  cancelled: "bg-[rgba(140,139,147,0.12)] text-[#8C8B93]",
  owner: "bg-[rgba(255,59,48,0.12)] text-[#FF3B30]",
  member: "bg-[rgba(140,139,147,0.12)] text-[#8C8B93]",
};

export function Badge({ status }: { status: string }) {
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium capitalize ${
        STATUS_STYLES[status] ?? STATUS_STYLES.member
      }`}
    >
      {status === "live" && <span className="live-dot h-1.5 w-1.5 rounded-full bg-[#FF3B30]" />}
      {status}
    </span>
  );
}

export function EmptyState({
  title,
  description,
  action,
}: { title: string; description: string; action?: ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center rounded-xl border border-dashed border-[#26262E] px-6 py-16 text-center">
      <h3 className="font-[family-name:var(--font-display)] text-lg font-semibold">{title}</h3>
      <p className="mt-2 max-w-sm text-sm text-[#8C8B93]">{description}</p>
      {action && <div className="mt-6">{action}</div>}
    </div>
  );
}

export function Input(props: React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      {...props}
      className={`w-full rounded-md border border-[#26262E] bg-[#15151B] px-4 py-2 text-sm text-[#F2F0EB] placeholder:text-[#5C5B63] focus:border-[#FF3B30] ${
        props.className ?? ""
      }`}
    />
  );
}

export function Textarea(props: React.TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return (
    <textarea
      {...props}
      className={`w-full rounded-md border border-[#26262E] bg-[#15151B] px-4 py-2 text-sm text-[#F2F0EB] placeholder:text-[#5C5B63] focus:border-[#FF3B30] ${
        props.className ?? ""
      }`}
    />
  );
}

export function Label({ children }: { children: ReactNode }) {
  return <label className="mb-1.5 block text-xs font-medium uppercase tracking-wide text-[#8C8B93]">{children}</label>;
}
