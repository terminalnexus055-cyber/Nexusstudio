"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { logout } from "@/app/auth/actions";

const NAV = [
  { href: "/dashboard", label: "Dashboard" },
  { href: "/teams", label: "Teams" },
  { href: "/meetings", label: "Sessions" },
  { href: "/settings", label: "Settings" },
];

export default function AppShell({
  userName,
  teams,
  children,
}: { userName: string; teams: any[]; children: React.ReactNode }) {
  const pathname = usePathname();

  return (
    <div className="flex min-h-screen">
      <aside className="hidden w-60 flex-col border-r border-[#26262E] bg-[#0E0E12] p-6 md:flex">
        <div className="mb-10 flex items-center gap-2">
          <span className="live-dot h-2.5 w-2.5 rounded-full bg-[#FF3B30]" />
          <span className="font-[family-name:var(--font-display)] text-lg font-semibold tracking-tight">
            Nexus Studio
          </span>
        </div>
        <nav className="flex flex-1 flex-col gap-1">
          {NAV.map((item) => {
            const active = pathname.startsWith(item.href);
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`rounded-md px-3 py-2 text-sm transition-colors ${
                  active ? "bg-[#1C1C24] text-[#F2F0EB]" : "text-[#8C8B93] hover:bg-[#1C1C24] hover:text-[#F2F0EB]"
                }`}
              >
                {item.label}
              </Link>
            );
          })}
        </nav>
        {teams?.length > 0 && (
          <div className="mt-6 border-t border-[#26262E] pt-4">
            <p className="mb-2 px-3 text-xs uppercase tracking-wider text-[#8C8B93]">Your teams</p>
            <div className="flex flex-col gap-1">
              {teams.slice(0, 4).map((team) => (
                <Link
                  key={team.id}
                  href={`/teams/${team.id}`}
                  className="truncate rounded-md px-3 py-1.5 text-sm text-[#8C8B93] hover:bg-[#1C1C24] hover:text-[#F2F0EB]"
                >
                  {team.name}
                </Link>
              ))}
            </div>
          </div>
        )}
      </aside>

      <div className="flex flex-1 flex-col">
        <header className="flex items-center justify-between border-b border-[#26262E] bg-[#0B0B0D] px-6 py-4 md:hidden">
          <div className="flex items-center gap-2">
            <span className="live-dot h-2 w-2 rounded-full bg-[#FF3B30]" />
            <span className="font-[family-name:var(--font-display)] font-semibold">Nexus Studio</span>
          </div>
          <form action={logout}>
            <button className="text-xs text-[#8C8B93]">Log out</button>
          </form>
        </header>

        <header className="hidden items-center justify-end gap-4 border-b border-[#26262E] px-8 py-4 md:flex">
          <span className="text-sm text-[#8C8B93]">{userName}</span>
          <form action={logout}>
            <button className="rounded-md border border-[#26262E] px-3 py-1.5 text-sm text-[#8C8B93] hover:text-[#F2F0EB]">
              Log out
            </button>
          </form>
        </header>

        <main className="flex-1 px-6 py-8 pb-24 md:px-10 md:pb-8">{children}</main>

        <nav className="fixed bottom-0 left-0 right-0 z-10 flex border-t border-[#26262E] bg-[#0E0E12] md:hidden">
          {NAV.map((item) => {
            const active = pathname.startsWith(item.href);
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`flex-1 py-3 text-center text-xs ${active ? "text-[#FF3B30]" : "text-[#8C8B93]"}`}
              >
                {item.label}
              </Link>
            );
          })}
        </nav>
      </div>
    </div>
  );
}
