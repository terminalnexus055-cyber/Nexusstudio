"use server";

import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";

export async function createTeam(formData: FormData) {
  const name = formData.get("name") as string;
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { data: team, error } = await supabase
    .from("teams")
    .insert({ name, owner_id: user.id })
    .select()
    .single();

  if (error) return { error: error.message };

  const { error: memberError } = await supabase
    .from("team_members")
    .insert({ team_id: team.id, user_id: user.id, role: "owner" });

  if (memberError) return { error: memberError.message };

  redirect(`/teams/${team.id}`);
}

export async function inviteMember(teamId: string, formData: FormData) {
  const email = formData.get("email") as string;
  const supabase = await createClient();

  const { data: profile, error: lookupError } = await supabase
    .from("profiles")
    .select("id")
    .eq("email", email)
    .maybeSingle();

  if (lookupError) return { error: lookupError.message };
  if (!profile) return { error: "No Nexus Studio account found with that email. They need to sign up first." };

  const { error } = await supabase
    .from("team_members")
    .insert({ team_id: teamId, user_id: profile.id, role: "member" });

  if (error) {
    if (error.code === "23505") return { error: "That person is already on the team." };
    return { error: error.message };
  }

  revalidatePath(`/teams/${teamId}`);
  return { success: true, message: "Member added to the team." };
}

export async function leaveTeam(teamId: string) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  await supabase.from("team_members").delete().eq("team_id", teamId).eq("user_id", user.id);
  redirect("/teams");
}
