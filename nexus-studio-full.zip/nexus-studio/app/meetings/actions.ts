"use server";

import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { randomUUID } from "crypto";

export async function createMeeting(formData: FormData) {
  const team_id = formData.get("team_id") as string;
  const title = formData.get("title") as string;
  const description = formData.get("description") as string;
  const start_time = formData.get("start_time") as string;

  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const roomName = `nexus-${randomUUID()}`;

  const { data: meeting, error } = await supabase
    .from("meetings")
    .insert({
      team_id,
      created_by: user.id,
      title,
      description: description || null,
      start_time: new Date(start_time).toISOString(),
      livekit_room_name: roomName,
    })
    .select()
    .single();

  if (error) return { error: error.message };

  redirect(`/meetings/${meeting.id}`);
}

export async function updateMeeting(meetingId: string, formData: FormData) {
  const title = formData.get("title") as string;
  const description = formData.get("description") as string;
  const start_time = formData.get("start_time") as string;

  const supabase = await createClient();
  const { error } = await supabase
    .from("meetings")
    .update({
      title,
      description: description || null,
      start_time: new Date(start_time).toISOString(),
    })
    .eq("id", meetingId);

  if (error) return { error: error.message };

  redirect(`/meetings/${meetingId}`);
}

export async function cancelMeeting(meetingId: string) {
  const supabase = await createClient();
  await supabase.from("meetings").update({ status: "cancelled" }).eq("id", meetingId);
  revalidatePath(`/meetings/${meetingId}`);
}
