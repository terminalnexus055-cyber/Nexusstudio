"use client";

import { useState } from "react";
import { inviteMember } from "@/app/teams/actions";
import { Input, Button } from "@/components/ui";

export default function InviteForm({ teamId }: { teamId: string }) {
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(formData: FormData) {
    setError(null);
    setMessage(null);
    const result = await inviteMember(teamId, formData);
    if (result?.error) setError(result.error);
    if (result?.success) setMessage(result.message);
  }

  return (
    <div className="mt-4 space-y-2">
      <form action={handleSubmit} className="flex gap-2">
        <Input name="email" type="email" placeholder="teammate@email.com" required className="flex-1" />
        <Button type="submit" variant="secondary">Invite</Button>
      </form>
      {error && <p className="text-sm text-[#FF3B30]">{error}</p>}
      {message && <p className="text-sm text-[#34C759]">{message}</p>}
    </div>
  );
}
