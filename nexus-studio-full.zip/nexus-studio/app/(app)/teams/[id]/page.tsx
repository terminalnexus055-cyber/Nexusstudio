import { notFound } from "next/navigation";
import Link from "next/link";
import { getTeam, getTeamMembers, getTeamMeetings, getCurrentProfile } from "@/lib/queries";
import { Card, Badge, Button, EmptyState } from "@/components/ui";
import { formatDateTime } from "@/lib/format";
import InviteForm from "./InviteForm";
import LeaveTeamButton from "./LeaveTeamButton";

export default async function TeamPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const team = await getTeam(id);
  if (!team) notFound();

  const [members, meetings, profile] = await Promise.all([
    getTeamMembers(id),
    getTeamMeetings(id),
    getCurrentProfile(),
  ]);

  const isOwner = team.owner_id === profile?.id;

  return (
    <div className="space-y-10">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="font-[family-name:var(--font-display)] text-2xl font-semibold">{team.name}</h1>
          <p className="mt-1 text-sm text-[#8C8B93]">
            {members.length} member{members.length !== 1 ? "s" : ""}
          </p>
        </div>
        <div className="flex gap-2">
          <Link href={`/meetings/new?team=${team.id}`}><Button>Schedule session</Button></Link>
          {!isOwner && <LeaveTeamButton teamId={team.id} />}
        </div>
      </div>

      <section>
        <h2 className="mb-4 text-sm font-medium uppercase tracking-wide text-[#8C8B93]">Members</h2>
        <Card>
          <ul className="divide-y divide-[#26262E]">
            {members.map((m: any) => (
              <li key={m.id} className="flex items-center justify-between py-3 first:pt-0 last:pb-0">
                <div>
                  <p className="text-sm font-medium">{m.profiles?.name}</p>
                  <p className="text-xs text-[#8C8B93]">{m.profiles?.email}</p>
                </div>
                <Badge status={m.role} />
              </li>
            ))}
          </ul>
        </Card>
        {isOwner && <InviteForm teamId={team.id} />}
      </section>

      <section>
        <h2 className="mb-4 text-sm font-medium uppercase tracking-wide text-[#8C8B93]">Sessions</h2>
        {meetings.length === 0 ? (
          <EmptyState
            title="No sessions yet"
            description="Schedule your first recording session for this team."
            action={<Link href={`/meetings/new?team=${team.id}`}><Button>Schedule session</Button></Link>}
          />
        ) : (
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {meetings.map((m: any) => (
              <Link key={m.id} href={`/meetings/${m.id}`}>
                <Card className="h-full transition-colors hover:border-[#3A3A44]">
                  <div className="flex items-start justify-between gap-2">
                    <h3 className="font-medium leading-snug">{m.title}</h3>
                    <Badge status={m.status} />
                  </div>
                  <p className="mt-3 font-[family-name:var(--font-mono)] text-xs text-[#8C8B93]">
                    {formatDateTime(m.start_time)}
                  </p>
                </Card>
              </Link>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
