"use client";

import { leaveTeam } from "@/app/teams/actions";
import { Button } from "@/components/ui";

export default function LeaveTeamButton({ teamId }: { teamId: string }) {
  async function handleLeave() {
    await leaveTeam(teamId);
  }
  return (
    <form action={handleLeave}>
      <Button variant="danger" type="submit">Leave team</Button>
    </form>
  );
}
