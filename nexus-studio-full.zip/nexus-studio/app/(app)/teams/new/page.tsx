"use client";

import { useState } from "react";
import { createTeam } from "@/app/teams/actions";
import { Input, Label, Button } from "@/components/ui";

export default function NewTeamPage() {
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(formData: FormData) {
    setError(null);
    const result = await createTeam(formData);
    if (result?.error) setError(result.error);
  }

  return (
    <div className="max-w-md space-y-6">
      <h1 className="font-[family-name:var(--font-display)] text-2xl font-semibold">Create a team</h1>
      <form action={handleSubmit} className="space-y-4">
        <div>
          <Label>Team name</Label>
          <Input name="name" placeholder="e.g. The Studio Crew" required />
        </div>
        {error && <p className="text-sm text-[#FF3B30]">{error}</p>}
        <Button type="submit">Create team</Button>
      </form>
    </div>
  );
}
