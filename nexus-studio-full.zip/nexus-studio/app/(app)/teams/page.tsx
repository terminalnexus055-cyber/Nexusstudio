import Link from "next/link";
import { getMyTeams } from "@/lib/queries";
import { Card, Badge, Button, EmptyState } from "@/components/ui";

export default async function TeamsPage() {
  const teams = await getMyTeams();
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="font-[family-name:var(--font-display)] text-2xl font-semibold">Teams</h1>
        <Link href="/teams/new"><Button>New team</Button></Link>
      </div>
      {teams.length === 0 ? (
        <EmptyState
          title="No teams yet"
          description="Create your first team to start scheduling recording sessions."
          action={<Link href="/teams/new"><Button>Create a team</Button></Link>}
        />
      ) : (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {teams.map((t: any) => (
            <Link key={t.id} href={`/teams/${t.id}`}>
              <Card className="h-full transition-colors hover:border-[#3A3A44]">
                <div className="flex items-center justify-between">
                  <h3 className="font-medium">{t.name}</h3>
                  <Badge status={t.role} />
                </div>
              </Card>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
