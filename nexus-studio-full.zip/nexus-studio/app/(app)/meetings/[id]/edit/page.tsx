import { notFound } from "next/navigation";
import { getMeeting } from "@/lib/queries";
import { toDatetimeLocal } from "@/lib/format";
import EditMeetingForm from "./EditMeetingForm";

export default async function EditMeetingPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const meeting = await getMeeting(id);
  if (!meeting) notFound();

  return (
    <div className="max-w-md space-y-6">
      <h1 className="font-[family-name:var(--font-display)] text-2xl font-semibold">Edit session</h1>
      <EditMeetingForm meeting={meeting} defaultStart={toDatetimeLocal(meeting.start_time)} />
    </div>
  );
}
