"use client";

import { useState } from "react";
import { updateMeeting } from "@/app/meetings/actions";
import { Input, Label, Textarea, Button } from "@/components/ui";

export default function EditMeetingForm({ meeting, defaultStart }: { meeting: any; defaultStart: string }) {
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(formData: FormData) {
    setError(null);
    const result = await updateMeeting(meeting.id, formData);
    if (result?.error) setError(result.error);
  }

  return (
    <form action={handleSubmit} className="space-y-4">
      <div>
        <Label>Title</Label>
        <Input name="title" defaultValue={meeting.title} required />
      </div>
      <div>
        <Label>Description</Label>
        <Textarea name="description" defaultValue={meeting.description ?? ""} rows={3} />
      </div>
      <div>
        <Label>Start time</Label>
        <Input name="start_time" type="datetime-local" defaultValue={defaultStart} required />
      </div>
      {error && <p className="text-sm text-[#FF3B30]">{error}</p>}
      <Button type="submit">Save changes</Button>
    </form>
  );
}
