import { notFound } from "next/navigation";
import { getMeeting } from "@/lib/queries";
import { Card } from "@/components/ui";

export default async function MeetingRoomPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const meeting = await getMeeting(id);
  if (!meeting) notFound();

  return (
    <div className="flex min-h-[60vh] items-center justify-center">
      <Card className="max-w-md text-center">
        <span className="live-dot mx-auto mb-4 block h-3 w-3 rounded-full bg-[#FF3B30]" />
        <h1 className="font-[family-name:var(--font-display)] text-xl font-semibold">{meeting.title}</h1>
        <p className="mt-2 text-sm text-[#8C8B93]">
          The call room isn&apos;t wired up yet — this is where the LiveKit video session loads once Phase 5 is built.
        </p>
        <p className="mt-4 font-[family-name:var(--font-mono)] text-xs text-[#5C5B63]">
          room: {meeting.livekit_room_name}
        </p>
      </Card>
    </div>
  );
}
