"use client";

import { cancelMeeting } from "@/app/meetings/actions";
import { Button } from "@/components/ui";

export default function CancelMeetingButton({ meetingId }: { meetingId: string }) {
  async function handleCancel() {
    if (confirm("Cancel this session?")) await cancelMeeting(meetingId);
  }
  return (
    <form action={handleCancel}>
      <Button variant="danger" type="submit">Cancel session</Button>
    </form>
  );
}
