import { notFound } from "next/navigation";
import Link from "next/link";
import { getMeeting, getMeetingParticipants } from "@/lib/queries";
import { Card, Badge, Button } from "@/components/ui";
import { formatDateTime } from "@/lib/format";
import CancelMeetingButton from "./CancelMeetingButton";

export default async function MeetingPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const meeting = await getMeeting(id);
  if (!meeting) notFound();

  const participants = await getMeetingParticipants(id);

  return (
    <div className="max-w-2xl space-y-8">
      <div>
        <div className="flex items-start justify-between gap-4">
          <div>
            <p className="text-xs uppercase tracking-wide text-[#8C8B93]">{meeting.teams?.name}</p>
            <h1 className="mt-1 font-[family-name:var(--font-display)] text-2xl font-semibold">{meeting.title}</h1>
          </div>
          <Badge status={meeting.status} />
        </div>
        {meeting.description && <p className="mt-3 text-sm text-[#8C8B93]">{meeting.description}</p>}
        <p className="mt-4 font-[family-name:var(--font-mono)] text-sm text-[#8C8B93]">
          {formatDateTime(meeting.start_time)}
        </p>
      </div>

      {meeting.status !== "cancelled" && meeting.status !== "completed" && (
        <Card>
          <p className="text-sm text-[#8C8B93]">Ready to record? Join the call to bring your team together.</p>
          <Link href={`/meetings/${meeting.id}/room`} className="mt-4 inline-block">
            <Button>Join session</Button>
          </Link>
        </Card>
      )}

      <section>
        <h2 className="mb-3 text-sm font-medium uppercase tracking-wide text-[#8C8B93]">Participants</h2>
        <Card>
          {participants.length === 0 ? (
            <p className="text-sm text-[#8C8B93]">No one has joined yet.</p>
          ) : (
            <ul className="divide-y divide-[#26262E]">
              {participants.map((p: any) => (
                <li key={p.id} className="flex items-center justify-between py-2 first:pt-0 last:pb-0">
                  <span className="text-sm">{p.profiles?.name}</span>
                  <span className="font-[family-name:var(--font-mono)] text-xs text-[#8C8B93]">
                    {p.left_at ? "left" : p.joined_at ? "in session" : "invited"}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </Card>
      </section>

      {meeting.status === "scheduled" && (
        <div className="flex gap-3">
          <Link href={`/meetings/${meeting.id}/edit`}><Button variant="secondary">Edit session</Button></Link>
          <CancelMeetingButton meetingId={meeting.id} />
        </div>
      )}
    </div>
  );
}
