"use client";

import { useState } from "react";
import Link from "next/link";
import { signup } from "@/app/auth/actions";
import AuthCard from "@/components/AuthCard";
import { Input, Label, Button } from "@/components/ui";

export default function SignupPage() {
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(formData: FormData) {
    setError(null);
    setMessage(null);
    const result = await signup(formData);
    if (result?.error) setError(result.error);
    if (result?.success) setMessage(result.message);
  }

  return (
    <AuthCard>
      <div>
        <h1 className="font-[family-name:var(--font-display)] text-2xl font-semibold">Create your account</h1>
        <p className="mt-1 text-sm text-[#8C8B93]">Set up your studio, on any device.</p>
      </div>
      <form action={handleSubmit} className="space-y-4">
        <div>
          <Label>Full name</Label>
          <Input name="name" type="text" required />
        </div>
        <div>
          <Label>Email</Label>
          <Input name="email" type="email" required />
        </div>
        <div>
          <Label>Password</Label>
          <Input name="password" type="password" required minLength={6} />
        </div>
        {error && <p className="text-sm text-[#FF3B30]">{error}</p>}
        {message && <p className="text-sm text-[#34C759]">{message}</p>}
        <Button type="submit" className="w-full">Sign up</Button>
      </form>
      <p className="text-sm text-[#8C8B93]">
        Already have an account?{" "}
        <Link href="/login" className="text-[#F2F0EB] underline">Log in</Link>
      </p>
    </AuthCard>
  );
}
