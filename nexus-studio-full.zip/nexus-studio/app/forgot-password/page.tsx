"use client";

import { useState } from "react";
import { requestPasswordReset } from "@/app/auth/actions";
import AuthCard from "@/components/AuthCard";
import { Input, Label, Button } from "@/components/ui";

export default function ForgotPasswordPage() {
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(formData: FormData) {
    setError(null);
    setMessage(null);
    const result = await requestPasswordReset(formData);
    if (result?.error) setError(result.error);
    if (result?.success) setMessage(result.message);
  }

  return (
    <AuthCard>
      <div>
        <h1 className="font-[family-name:var(--font-display)] text-2xl font-semibold">Reset your password</h1>
        <p className="mt-1 text-sm text-[#8C8B93]">We&apos;ll email you a link to set a new one.</p>
      </div>
      <form action={handleSubmit} className="space-y-4">
        <div>
          <Label>Email</Label>
          <Input name="email" type="email" required />
        </div>
        {error && <p className="text-sm text-[#FF3B30]">{error}</p>}
        {message && <p className="text-sm text-[#34C759]">{message}</p>}
        <Button type="submit" className="w-full">Send reset link</Button>
      </form>
    </AuthCard>
  );
}
