"use client";

import { useState } from "react";
import { updatePassword } from "@/app/auth/actions";
import AuthCard from "@/components/AuthCard";
import { Input, Label, Button } from "@/components/ui";

export default function ResetPasswordPage() {
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(formData: FormData) {
    setError(null);
    const result = await updatePassword(formData);
    if (result?.error) setError(result.error);
  }

  return (
    <AuthCard>
      <div>
        <h1 className="font-[family-name:var(--font-display)] text-2xl font-semibold">Set a new password</h1>
      </div>
      <form action={handleSubmit} className="space-y-4">
        <div>
          <Label>New password</Label>
          <Input name="password" type="password" required minLength={6} />
        </div>
        {error && <p className="text-sm text-[#FF3B30]">{error}</p>}
        <Button type="submit" className="w-full">Update password</Button>
      </form>
    </AuthCard>
  );
}
