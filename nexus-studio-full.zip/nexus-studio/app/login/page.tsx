"use client";

import { useState } from "react";
import Link from "next/link";
import { login } from "@/app/auth/actions";
import AuthCard from "@/components/AuthCard";
import { Input, Label, Button } from "@/components/ui";

export default function LoginPage() {
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(formData: FormData) {
    setError(null);
    const result = await login(formData);
    if (result?.error) setError(result.error);
  }

  return (
    <AuthCard>
      <div>
        <h1 className="font-[family-name:var(--font-display)] text-2xl font-semibold">Log in</h1>
        <p className="mt-1 text-sm text-[#8C8B93]">Get back to your team&apos;s sessions.</p>
      </div>
      <form action={handleSubmit} className="space-y-4">
        <div>
          <Label>Email</Label>
          <Input name="email" type="email" required />
        </div>
        <div>
          <Label>Password</Label>
          <Input name="password" type="password" required />
        </div>
        {error && <p className="text-sm text-[#FF3B30]">{error}</p>}
        <Button type="submit" className="w-full">Log in</Button>
      </form>
      <div className="flex justify-between text-sm text-[#8C8B93]">
        <Link href="/signup" className="hover:text-[#F2F0EB]">Create account</Link>
        <Link href="/forgot-password" className="hover:text-[#F2F0EB]">Forgot password?</Link>
      </div>
    </AuthCard>
  );
}
